package com.example.travel_manager;

public class Information {
    private  String place;

    public Information() {
    }

    public Information(String place) {
        this.place = place;
    }

    public String getPlace() {
        return place;
    }

    public void setPlace(String place) {
        this.place = place;
    }
}
