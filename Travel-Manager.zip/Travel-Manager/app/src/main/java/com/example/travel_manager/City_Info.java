package com.example.travel_manager;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class City_Info extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        ///todo
    }
}