package com.example.travel_manager;

public class TourismPlace{
    public String icon;
    public String name;
    public String vicinity;
    public  String photoUrl;

    public TourismPlace(String icon, String name, String vicinity, String photoUrl) {
        this.icon = icon;
        this.name = name;
        this.vicinity = vicinity;
        this.photoUrl = photoUrl;
    }
}
